package mytld.mycompany.myapp.mysubsystem.repository;

import java.util.List;

import mytld.mycompany.myapp.mysubsystem.domain.Product;


public interface ProductRepository {

	Product find(Long id);

	List<Product> findAll();

	void update(Product product);
	
	void delete(Product product);
}
