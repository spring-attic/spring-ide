package mytld.mycompany.myapp.mysubsystem.service.internal;

import java.util.List;

import mytld.mycompany.myapp.mysubsystem.domain.Product;
import mytld.mycompany.myapp.mysubsystem.repository.ProductRepository;
import mytld.mycompany.myapp.mysubsystem.service.ProductService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service(value="productService")
public class ProductServiceImpl implements ProductService {

	@Autowired ProductRepository productRepository;
	
	public void setProductDao(ProductRepository productDao) {
		this.productRepository = productDao;
	}
	
	@Transactional(readOnly=true)
	public Product findProduct(long id) {
		return productRepository.find(id);
	}
	
	@Transactional(readOnly=true)
	public List<Product> findProducts() {
		return productRepository.findAll();
	}
	
	@Transactional 
	public void deleteProduct(Long productId) {
		productRepository.delete(productRepository.find(productId));
	}

	@Transactional
	public void updateProduct(Product product) {
		productRepository.update(product);
	}
}
