package mytld.mycompany.myapp.mysubsystem.web;

import java.util.List;

import mytld.mycompany.myapp.mysubsystem.domain.Product;
import mytld.mycompany.myapp.mysubsystem.service.ProductService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class ProductController {
	
	@Autowired private ProductService productService;
	
	public void setCatalogService(ProductService catalogService) {
		this.productService = catalogService;
	}

	@RequestMapping("/productSummary.htm")
	@ModelAttribute("products")
	public List<Product> productSummary() {
		return productService.findProducts();
	}

	@RequestMapping("/productDetails.htm")
	public Product productDetails(Long productId) 
	throws ServletRequestBindingException {
		return productService.findProduct(productId);
	}
	
	@RequestMapping("/productDelete.htm")
	public String productDelete(Long productId)	{
		productService.deleteProduct(productId);
		return "redirect:productSummary.htm";
	}
}
