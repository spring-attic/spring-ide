insert into products (id, name) values(1001,'ProductA')
insert into products (id, name) values(1002,'ProductB')
insert into products (id, name) values(1003,'ProductC')
insert into products (id, name) values(1004,'ProductD')
