package mytld.mycompany.myapp.mysubsystem.web;

import mytld.mycompany.myapp.mysubsystem.domain.Product;
import mytld.mycompany.myapp.mysubsystem.service.ProductService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;


@Controller
@SessionAttributes("product")
@RequestMapping("/productEdit.htm")
public class EditProductController {
	@Autowired private ProductService productService;

	@RequestMapping(method = RequestMethod.GET)
	public Product setupForm(@RequestParam(required=false) Long productId) {
		if (productId != null) {
			return productService.findProduct(productId);
		} else {
			return new Product();
		}
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public String productEdit(Product product) {
		productService.updateProduct(product);
		return "redirect:productSummary.htm";
	}
}
