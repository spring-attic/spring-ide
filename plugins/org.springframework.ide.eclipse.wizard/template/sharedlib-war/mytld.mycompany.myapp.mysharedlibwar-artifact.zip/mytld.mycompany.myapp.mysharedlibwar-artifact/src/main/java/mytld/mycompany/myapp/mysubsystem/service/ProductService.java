package mytld.mycompany.myapp.mysubsystem.service;

import java.util.List;

import mytld.mycompany.myapp.mysubsystem.domain.Product;


public interface ProductService {
	Product findProduct(long id);
	
	List<Product> findProducts();
	
	void deleteProduct(Long productId);

	void updateProduct(Product product);	
}
