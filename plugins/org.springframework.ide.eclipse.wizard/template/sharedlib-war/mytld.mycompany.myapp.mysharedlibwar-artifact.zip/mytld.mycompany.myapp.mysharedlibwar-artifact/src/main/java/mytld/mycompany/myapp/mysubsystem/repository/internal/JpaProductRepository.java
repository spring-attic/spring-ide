package mytld.mycompany.myapp.mysubsystem.repository.internal;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import mytld.mycompany.myapp.mysubsystem.domain.Product;
import mytld.mycompany.myapp.mysubsystem.repository.ProductRepository;

import org.springframework.stereotype.Repository;


@Repository(value="productRepository")
public class JpaProductRepository implements ProductRepository {

	@PersistenceContext private EntityManager em;
	
	public void setEntityManager(EntityManager em) {
		this.em = em;
	}

	public void delete(Product product) {
		em.remove(product);
	}

	public Product find(Long id) {
		return em.find(Product.class, id);
	}

    @SuppressWarnings("unchecked")
	public List<Product> findAll() {
	    return em.createQuery("select p from Product p").getResultList();
	}

	public void update(Product product) {
		if (product.getId() == null) {
			em.persist(product);
		} else {
			em.merge(product);
		}
	}
	
}
