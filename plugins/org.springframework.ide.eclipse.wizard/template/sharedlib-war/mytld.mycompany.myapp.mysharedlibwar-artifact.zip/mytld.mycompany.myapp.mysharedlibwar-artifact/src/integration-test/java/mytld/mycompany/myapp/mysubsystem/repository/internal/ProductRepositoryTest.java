package mytld.mycompany.myapp.mysubsystem.repository.internal;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import mytld.mycompany.myapp.mysubsystem.domain.Product;
import mytld.mycompany.myapp.mysubsystem.repository.ProductRepository;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.AfterTransaction;
import org.springframework.transaction.annotation.Transactional;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="/META-INF/spring/*.xml")
@Transactional
public class ProductRepositoryTest {

	@Autowired ProductRepository productRepository;
	@PersistenceContext EntityManager em;

	@Test
	public void load() {
		// nothing to do here
	}
	
	@Test
	public void find() {
		Long id = new Long(1001);
		Product product = productRepository.find(id);
		assertNotNull(product);
		assertTrue(id.equals(product.getId()));
	}
	
	@Test
	public void create() {
		Product newProduct = new Product();
		newProduct.setName("newProduct");
		productRepository.update(newProduct);
		Long id = newProduct.getId();
		
		em.flush();
		em.clear();
		
		Product savedProduct = productRepository.find(id);
		assertNotNull(savedProduct);
	}
	
	@Test
	public void update() {
		Product product = productRepository.find(1001L);
		product.setName("foo");
		productRepository.update(product);
		
		em.flush();
		em.clear();
		
		Product updatedProduct = productRepository.find(1001L);
		assertEquals("foo", updatedProduct.getName());
	}

	@Test
	public void delete() {
		productRepository.delete(productRepository.find(1001L));
		
		em.flush();
		em.clear();
		
		Product deletedProduct = productRepository.find(1001L);
		assertNull(deletedProduct);
	}
	
	@After
	public void flush() {
		em.flush();
	}
}
