package mytld.mycompany.myapp.mysubsystem.service.internal;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import mytld.mycompany.myapp.mysubsystem.domain.Product;
import mytld.mycompany.myapp.mysubsystem.service.ProductService;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="/META-INF/spring/*.xml")
public class ProductServiceTest {

	@Autowired ProductService productService;

	@Test
	public void load() {
		// nothing to do here
	}
	
	@Test
	public void findProducts() {
		List<Product> plist = productService.findProducts();
		assertNotNull(plist);
		assertTrue(plist.size() > 0);
		assertNotNull(plist.get(0).getId());
		assertNotNull(plist.get(0).getName());
	}
	
	@Test
	public void createProduct() {
		Product newProduct = new Product();
		newProduct.setName("newProduct");
		productService.updateProduct(newProduct);
		
		assertNotNull(productService.findProduct(newProduct.getId()));
	}
	
	@Test
	public void deleteProduct() {
		productService.deleteProduct(1001L);
		
		assertNull(productService.findProduct(1001L));
	}
	
	@Test
	public void updateProduct() {
		
	}
}
