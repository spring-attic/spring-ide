<?php
    $dbhost = "mysqlserver";
    $dbuser = "dbaccessrw";
    $dbpass = "dbaccessrwpassword";
?>