<?php
    $dbhost = "mysqlserver";
    $dbuser = "dbaccessro";
    $dbpass = "dbaccessropassword";
?>