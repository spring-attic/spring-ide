Search CVS is a tool for converting cvs commits into a mysql database, which 
can be updated without worry of data duplication. The database is then searchable 
via a web page run on www.eclipse.org.

Web Server Quick Setup:

1. See searchcvs/www/README.

----

Additional details on setup and on using this tool can be found here:

http://wiki.eclipse.org/index.php/Search_CVS
