These files are for reference, but are not required to run the 
Ant scripts + tasks.