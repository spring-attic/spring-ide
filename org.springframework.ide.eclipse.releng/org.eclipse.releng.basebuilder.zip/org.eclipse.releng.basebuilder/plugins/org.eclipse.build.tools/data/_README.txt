These files are sample data to get you started, generated using 
the feedPublish.*.properties files in the properties/ folder.