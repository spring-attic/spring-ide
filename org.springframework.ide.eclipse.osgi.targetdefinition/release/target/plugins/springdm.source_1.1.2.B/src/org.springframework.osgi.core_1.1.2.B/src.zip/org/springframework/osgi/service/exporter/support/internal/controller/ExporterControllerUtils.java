/*
 * Copyright 2006-2008 the original author or authors.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.osgi.service.exporter.support.internal.controller;

import java.lang.reflect.Field;

import org.springframework.osgi.service.exporter.support.OsgiServiceFactoryBean;

/**
 * Utility class that retrieves the controller associated with a given importer.
 * 
 * @author Costin Leau
 * 
 */
public abstract class ExporterControllerUtils {

	private static final String FIELD_NAME = "controller";

	private static final Field field;

	static {
		try {
			field = OsgiServiceFactoryBean.class.getDeclaredField(FIELD_NAME);
			field.setAccessible(true);
		}
		catch (NoSuchFieldException ex) {
			throw (RuntimeException) new IllegalStateException("Cannot read field [" + FIELD_NAME + "] on class ["
					+ OsgiServiceFactoryBean.class + "]").initCause(ex);
		}
	}


	public static ExporterInternalActions getControllerFor(Object exporter) {
		try {
			return (ExporterInternalActions) field.get(exporter);
		}
		catch (IllegalAccessException iae) {
			throw (RuntimeException) new IllegalArgumentException("Cannot access field [" + FIELD_NAME
					+ "] on object [" + exporter + "]").initCause(iae);
		}
	}
}
